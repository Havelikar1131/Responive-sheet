## hero section ##
    - headerr
       - navbar( contact us,about us,service,home)
       - button(username)
       - img(logo)
## section
    - div ( div one with class left)
        -strong Element(30px text size)
                loundry service(blue text 30px text size)
        -p(loundry information)
        -button(book a service today)
    - div( div second with class right)
        -img(loundey.png)
        
